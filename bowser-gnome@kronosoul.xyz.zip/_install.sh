#glib-compile-schemas schemas
cp -r ./ ~/.local/share/gnome-shell/extensions/bowser-gnome@kronosoul.xyz