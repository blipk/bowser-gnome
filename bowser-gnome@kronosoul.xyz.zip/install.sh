#!/bin/bash
cp -r ./bowser-gnome@kronosoul.xyz ~/.local/share/gnome-shell/extensions/bowser-gnome@kronosoul.xyz