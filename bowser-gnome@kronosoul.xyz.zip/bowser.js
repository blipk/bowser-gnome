#!/usr/bin/env gjs

'use strict';

const Gdk = imports.gi.Gdk;
const Gio = imports.gi.Gio;
const GLib = imports.gi.GLib;
const GObject = imports.gi.GObject;
const Gtk = imports.gi.Gtk;

// Find the root datadir of the extension
function get_datadir() {
    let m = /@(.+):\d+/.exec((new Error()).stack.split('\n')[1]);
    return Gio.File.new_for_path(m[1]).get_parent().get_parent().get_path();
}

window.bowser = {extdatadir: get_datadir()};
imports.searchPath.unshift(bowser.extdatadir);

bowser.app_id = 'org.gnome.Shell.Extensions.GSConnect';
bowser.app_path = '/org/gnome/Shell/Extensions/GSConnect';
bowser.is_local = bowser.extdatadir.startsWith(GLib.get_user_data_dir());
bowser.metadata = (() => {
    let data = GLib.file_get_contents(bowser.extdatadir + '/metadata.json')[1];

    return JSON.parse(imports.byteArray.toString(data));
})();



// Local Imports
const Me = extensionUtils.getCurrentExtension();

const Service = GObject.registerClass({
    GTypeName: 'BowserService',
    Properties: {
        'discoverable': GObject.ParamSpec.boolean(
            'discoverable',
            'Discoverable',
            'Whether the service responds to discovery requests',
            GObject.ParamFlags.READWRITE,
            false
        ),
        'id': GObject.ParamSpec.string(
            'id',
            'Id',
            'The service id',
            GObject.ParamFlags.READWRITE,
            null
        ),
        'name': GObject.ParamSpec.string(
            'name',
            'deviceName',
            'The name announced to the network',
            GObject.ParamFlags.READWRITE,
            'Bowser'
        )
    }
}, class BowserService extends Gtk.Application {
    _init() {
        super._init({
            application_id: bowser.app_id,
            flags: Gio.ApplicationFlags.HANDLES_OPEN
        });

        GLib.set_prgname('Bowser');
        GLib.set_application_name('Bowser');
        
        // Command-line
        this._initOptions();
    }


    /**
     * GActions
     */
    _initActions() {
        let actions = [
            ['preferences', this._preferences],
            ['quit', () => this.quit()]
        ];

        for (let [name, callback, type] of actions) {
            let action = new Gio.SimpleAction({
                name: name,
                parameter_type: (type) ? new GLib.VariantType(type) : null
            });
            action.connect('activate', callback);
            this.add_action(action);
        }
    }

   
    _preferences() {
        let proc = new Gio.Subprocess({
            argv: [bowser.extdatadir + '/bowser-preferences']
        });
        proc.init(null);
        proc.wait_async(null, null);
    }

    vfunc_activate() {
        super.vfunc_activate();
    }

    vfunc_startup() {
        super.vfunc_startup();
        this.hold();

        /*// Init some resources
        let provider = new Gtk.CssProvider();
        provider.load_from_resource(bowser.app_path + '/application.css');
        Gtk.StyleContext.add_provider_for_screen(
            Gdk.Screen.get_default(),
            provider,
            Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
        );
        /* */

        // Ensure our handlers are registered
        try {
            let appInfo = Gio.DesktopAppInfo.new(`${bowser.app_id}.desktop`);
            appInfo.add_supports_type('text/html');
        } catch (e) {
            dev.log(e);
        }

        // GActions & GSettings
        this._initActions();
    }

    vfunc_dbus_register(connection, object_path) {
        if (!super.vfunc_dbus_register(connection, object_path))
            return false;

        this.objectManager = new Gio.DBusObjectManagerServer({
            connection: connection,
            object_path: object_path
        });
        
        return true;
    }

    vfunc_open(files, hint) {
        super.vfunc_open(files, hint);

        for (let file of files) {
            let action, parameter, title;

            try {
                switch (file.get_uri_scheme()) {
                    case 'sms':
                        title = _('Send SMS');
                        action = 'uriSms';
                        parameter = new GLib.Variant('s', file.get_uri());
                        break;

                    default:
                        throw new Error(`Unsupported URI: ${file.get_uri()}`);
                }

                // Launch bowser
                dev.log("DONE");
                print("DONE");
            } catch (e) {
                logError(e, `Bowser: Opening ${file.get_uri()}`);
            }
        }
    }

    vfunc_shutdown() {

        // Chain up last (application->priv->did_shutdown)
        super.vfunc_shutdown();
    }
    
    /*
     * CLI
     */
    _initOptions() {
        this.add_main_option(
            'version',
            'v'.charCodeAt(0),
            GLib.OptionFlags.NONE,
            GLib.OptionArg.NONE,
            _('Show release version'),
            null
        );
    }

    vfunc_handle_local_options(options) {
        try {
            if (options.contains('version')) {
                print(`Bowser ${bowser.metadata.version}`);
                return 0;
            }

            this.register(null);

            return 0;
        } catch (e) {
            dev.log(e);
            return 1;
        }
    }
});

(new Service()).run([imports.system.programInvocationName].concat(ARGV));

